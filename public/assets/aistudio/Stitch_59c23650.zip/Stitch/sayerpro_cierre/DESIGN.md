---
name: SayerPro Cierre
colors:
  surface: '#f9f9ff'
  surface-dim: '#d2daec'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eeff'
  surface-container-high: '#e0e8fa'
  surface-container-highest: '#dbe3f4'
  on-surface: '#141c28'
  on-surface-variant: '#424655'
  inverse-surface: '#29313e'
  inverse-on-surface: '#ebf1ff'
  outline: '#727787'
  outline-variant: '#c2c6d8'
  surface-tint: '#0056d1'
  primary: '#0054cc'
  on-primary: '#ffffff'
  primary-container: '#156bf9'
  on-primary-container: '#fefcff'
  inverse-primary: '#b2c5ff'
  secondary: '#365bad'
  on-secondary: '#ffffff'
  secondary-container: '#84a6fd'
  on-secondary-container: '#053889'
  tertiary: '#0054ca'
  on-tertiary: '#ffffff'
  tertiary-container: '#326ee6'
  on-tertiary-container: '#fefcff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2ff'
  primary-fixed-dim: '#b2c5ff'
  on-primary-fixed: '#001847'
  on-primary-fixed-variant: '#0040a0'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b1c5ff'
  on-secondary-fixed: '#001947'
  on-secondary-fixed-variant: '#184293'
  tertiary-fixed: '#dae2ff'
  tertiary-fixed-dim: '#b1c5ff'
  on-tertiary-fixed: '#001946'
  on-tertiary-fixed-variant: '#00419f'
  background: '#f9f9ff'
  on-background: '#141c28'
  surface-variant: '#dbe3f4'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  numeric-currency-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  numeric-currency-md:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  numeric-table:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2rem
  space-xxs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

The design system establishes a high-precision, utilitarian, and illuminated operational environment for financial closing, inventory reconciliation, and retail audit workflows across the Santa Rosa, Cuautepec, and Tlalne retail branches. 

### Emotional Response & Personality
The interface evokes absolute rigor, clarity, and trust. Because financial closing demands error-free reconciliation under high-pressure shift turnovers, the UI rejects extraneous decoration in favor of structural clarity, visual calm, and rapid scanning. The tone is institutional, transparent, and authoritative.

### Visual Style: Clean Corporate & Precision Functionalism
- **Surface Dominance:** Clean, illuminated canvases (~70% pure and tinted whites) that reduce eye fatigue in back-office environments.
- **Controlled Accents:** Intentional application of deep brand blues and operational action blues (~20%) to direct focus solely toward task progression, monetary discrepancies, and transactional confirmations.
- **Architectural Structure:** Subtle hairline dividers (1px), balanced tabular grids, and restrained 8px corner radii that project an orderly, dependable enterprise architecture.
- **The Brand Wave Accent:** Subtle multi-stripe semantic accents (incorporating the company's distinctive green, amber, and red triad) reserved strictly for branch categorization, progress indicators, and status summaries.

## Colors

The palette is tuned for high-legibility accounting sheets, cash-drawer reconciliation, and fiscal multi-store comparisons.

### Palette Architecture
- **Primary & Interactive Blue (`#1E6FFD`):** Primary brand accent, interactive links, primary callouts, and selected filter states.
- **Deep Navy (`#0B3B8C`):** High-level headers, primary balance cards, navigation framing, and authoritative operational totals.
- **Action Blue (`#1A5FD6`):** Focused interactive elements, active button states, and execution CTAs (e.g., "Confirmar Cierre de Caja").
- **Tonal Blues:**
  - `Light Blue (#8CB6FF)`: Focus rings, selected row indicators, and subtle informational pills.
  - `Soft Blue (#E8F0FF)`: Primary selection canvas, active row highlighting, and icon container badges.
  - `Alternate Blue/Neutral Canvas (#F5F8FF)`: Secondary column fills, data table alternating zebra strips, and drawer sub-sections.
- **Functional Grays:**
  - `Text Primary (#3A4250)`: Optimal contrast for continuous data entry and audit figures without the harshness of pure black.
  - `Text Secondary / Label (#6B7584)`: Timestamps, branch codes, inactive columns, and auxiliary labels.
  - `Structural Border (#E1E7F0)`: Clean 1px framing for data grids, ledger cards, and split panels.
- **Operational Semantics (Traffic-Light & Brand Triad Wave):**
  - `Success / Balanced Cash`: Background `#F0FDF4`, Border `#67E100`, Deep Text `#2F7A00`.
  - `Warning / Pending Authorization`: Background `#FFFBEB`, Border `#FCA800`, Deep Text `#8A5A00`.
  - `Error / Cash Discrepancy / Shortage`: Background `#FEF2F2`, Border `#F72800`, Deep Text `#C21F00`.

## Typography

The type system is powered exclusively by `Inter` to enforce clean geometric precision, exceptional legibility at small sizes, and flawless vertical metrics.

### Tabular Alignment & Numbers
All financial amounts, denomination counts (billetes/monedas), and currency summaries must enforce OpenType tabular figures (`font-variant-numeric: tabular-nums;` or `font-feature-settings: "tnum" 1`). This guarantees strict vertical decimal alignment across multi-row reconciliation tables.

### Hierarchy Rules
- **Display & Financial Metrics:** Reserved for top-line cash-drawer balances, total branch sales, and global closing reconciliations.
- **Labels & Headers:** Uppercase tracking (`letterSpacing: 0.04em`) applied to `label-sm` for table column identifiers and branch tags (e.g., `SANTA ROSA`, `CUAUTEPEC`, `TLALNE`).
- **Body & Tabular Entries:** Calibrated to 13px–14px to maximize data density without visual clustering or cognitive overload.

## Layout & Spacing

The layout is built upon an 8pt architectural grid system, optimized for compact transactional workflows on enterprise screens, POS terminals, and management tablets.

### Grid & Canvas Structure
- **Layout Model:** 12-column responsive fluid grid with fixed maximum width (`1600px`) to prevent metric distortion on ultra-wide monitors.
- **Breakpoints:**
  - `Mobile / POS Handheld (< 768px)`: 4 columns, 16px margins, 12px gutters. Data tables switch to vertical stacked transaction cards.
  - `Tablet / Back-Office Monitor (768px - 1199px)`: 8 columns, 24px margins, 16px gutters. Split-screen cashier vs. supervisor ledger.
  - `Desktop / Audit Station (>= 1200px)`: 12 columns, 32px margins, 24px gutters. Tri-store global overview with simultaneous cash breakdown drawers.

### Spacing Philosophy
- Use `space-xs` (4px) and `space-sm` (8px) for tightly coupled financial pairs (e.g., currency symbol + value, table cell vertical padding).
- Use `space-md` (16px) for interior card padding and form control separation.
- Use `space-lg` (24px) for section headers and multi-branch comparison blocks.

## Elevation & Depth

To maintain visual rigor and prevent muddy renders in high-glare retail environments, visual hierarchy relies on subtle tonal layering, 1px perimeter definition, and low-amplitude ambient diffusion rather than deep drop shadows.

### Elevation Levels
- **Level 0 (Base Canvas):** Background tone `#FFFFFF` for the core content canvas, alternated with `#F5F8FF` for side rails and sub-panels.
- **Level 1 (Cards & Data Tables):** Flat `#FFFFFF` surface enclosed with a 1px solid border in `#E1E7F0`. No shadow required in standard resting state.
- **Level 2 (Dropdowns, Branch Selectors & Floating Toolbars):** Background `#FFFFFF`, 1px border in `#E1E7F0`, ambient shadow: `0 4px 12px -2px rgba(11, 59, 140, 0.06), 0 2px 4px -1px rgba(11, 59, 140, 0.03)`.
- **Level 3 (Modal Confirmation & Cash Discrepancy Alerts):** Background `#FFFFFF`, 1px border in `#E1E7F0`, elevation shadow: `0 12px 32px -4px rgba(11, 59, 140, 0.12), 0 4px 12px -2px rgba(11, 59, 140, 0.04)`.

## Shapes

The design system uses a consistent `8px` (`0.5rem`) corner radius across all standard UI containers, striking a balance between modern ergonomics and disciplined financial order.

### Shape Scale
- **Containers & Cards:** `8px` (`roundedness: 2`). Enforces rectangular discipline for data density.
- **Input Fields & Buttons:** `8px` (`roundedness: 2`). Matches container harmony and provides unambiguous touch/click targets.
- **Pills & Status Tags:** Fully rounded pill (`9999px`) to immediately distinguish operational state tags from interactive rectangular buttons and data cells.
- **Multi-Stripe Brand Wave Accent:** A 3px bottom or left boundary accent with three adjacent 1px micro-stripes (Green `#67E100`, Amber `#FCA800`, Red `#F72800`) used exclusively as a visual anchor on active branch overview headers.

## Components

### Buttons
- **Primary Action (Cierre / Confirmar):** Background `#1A5FD6`, text `#FFFFFF`, border none, 8px radius, height 40px, padding horizontal 16px. Hover state `#1E6FFD`. Focus state: 2px ring in `#8CB6FF` with 2px offset.
- **Secondary (Guardar Borrador / Exportar):** Background `#E8F0FF`, text `#1A5FD6`, border 1px solid `#8CB6FF`, 8px radius, height 40px.
- **Destructive (Anular / Discrepancia Crítica):** Background `#FEF2F2`, text `#C21F00`, border 1px solid `#F72800`, 8px radius.

### Financial Input Fields (Cash Breakdown / Denominaciones)
- **Container:** Height 40px, border 1px solid `#E1E7F0`, radius 8px, background `#FFFFFF`, text `#3A4250`.
- **Text Alignment:** Numeric values right-aligned with fixed tabular numbers. Currency symbol (`$`) pinned left in `#6B7584`.
- **Focus State:** Border `#1E6FFD`, box-shadow `0 0 0 3px #E8F0FF`.
- **Error / Balance Descuadrado:** Border `#F72800`, box-shadow `0 0 0 3px #FEF2F2`.

### Status Badges & Semaphore Chips
- **Balanced (Cuadrado):** Pill shape, background `#F0FDF4`, border 1px solid `#67E100`, text `#2F7A00`, font size 12px, font-weight 600.
- **Warning (En Revisión):** Pill shape, background `#FFFBEB`, border 1px solid `#FCA800`, text `#8A5A00`.
- **Discrepancy (Diferencia Faltante/Sobrante):** Pill shape, background `#FEF2F2`, border 1px solid `#F72800`, text `#C21F00`.
- **Branch Selector Tags:** Neutral fill `#F5F8FF`, border 1px solid `#E1E7F0`, text `#3A4250`. When active: fill `#0B3B8C`, border `#0B3B8C`, text `#FFFFFF`.

### Financial Reconciliation Cards
- **Architecture:** White surface (`#FFFFFF`), 1px solid `#E1E7F0`, 8px radius, padding 16px. 
- **Header Structure:** Deep navy title (`#0B3B8C`) on the left, branch tag badge on the right.
- **Metric Row:** Large numeric balance (`numeric-currency-lg`), accompanied by a subtle subtitle indicating register ID and cashier name.

### Data Tables (Arqueo de Caja & Transacciones)
- **Header:** Height 36px, background `#F5F8FF`, border-bottom 1px solid `#E1E7F0`, text 11px uppercase in `#6B7584`, font-weight 600.
- **Rows:** Height 44px, background alternating `#FFFFFF` and `#FDFEFF`, border-bottom 1px solid `#E1E7F0`. Selected row: background `#E8F0FF`.
- **Cell Content:** Left-align concepts and payment types (Efectivo, Tarjeta, Transferencia), right-align monetary sums and piece quantities.

### Discrepancy Alert Banner
- Dedicated strip at the top of the closing screen. Background `#FEF2F2`, 1px solid border in `#F72800`, 8px radius. Contains bold discrepancy amount in `#C21F00`, cashier explanation input field, and supervisor signature trigger.